﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService
{

    /// <summary>
    /// Filter city by StateID
    /// </summary>
    /// <param name="ID"></param>
    /// <returns></returns>
    [WebMethod]
    public List<Cities> FindCityByID(string ID)
    {
        return GetCities().FindAll(x => x.StateId == int.Parse(ID));

    }
    /// <summary>
    /// Return list of cities.
    /// </summary>
    /// <returns></returns>
    public List<Cities> GetCities()
    {
        List<Cities> cities = new List<Cities>()
            {
                new Cities{CityID=1,StateId=1,Name="Lucknow"},
                new Cities{CityID=2,StateId=1,Name="Allahabad"},
                new Cities{CityID=3,StateId=2,Name="Patiala"},
                new Cities{CityID=4,StateId=2,Name="Amritsar"},
                new Cities{CityID=5,StateId=3,Name="Shimla"},
             
            };
        return cities;
    }


    /// <summary>
    /// Return List of states
    /// </summary>
    /// <returns></returns>
    [WebMethod]
    public List<State> GetStates()
    {

        List<State> states = new List<State>()
            {
                new State{StateId=1,Name="UP"},
                new State{StateId=2,Name="Punjab"},
                new State{StateId=3,Name="Himachal"}
            };
        return states;

    }
    /// <summary>
    /// 
    /// </summary>
    public class State
    {
        public int StateId { get; set; }
        public string Name { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class Cities
    {
        public int CityID { get; set; }
        public int StateId { get; set; }
        public string Name { get; set; }
    }

}

